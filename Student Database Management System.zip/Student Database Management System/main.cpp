#include <iostream>
#include <iomanip>
#include <fstream>
#include <cstring>
#include <cctype>
#include <cstdlib>
#include <cmath>
using namespace std;

class Data
{
public:
    void dataUpdate(char name[][99], char id[][99], char faculty[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int no_of_student);
    void dataAdd(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int& no_of_student);
    void dataDelete(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int& no_of_student);
};

class Search
{
public:
    void searchGender(char ic[][99], int count[], int no_of_student);
    void searchKeyword(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int count[], int no_of_student);

};

class Print
{
public:
    int printMenu();
    void printList(char name[][99],char id[][99],char faculty[][99],char ic[][99],char year_enroll[][99],char email[][99],char phone_no[][99],int count[],int no_of_student, int );
};

int main()
{
    Search obj1;
    Data get1;
    Print list1, list2;
	int no_of_student = 0, decision = 0, count[99] = { 0 };
	char whitespace[99];
	char name[99][99], id[99][99], faculty[99][99], ic[99][99], year_enroll[99][99], email[99][99], phone_no[99][99];
	ifstream inFile("record.txt", ios::in);
	while (inFile)
	{
		inFile.getline(name[no_of_student], 99);
		inFile.getline(id[no_of_student], 99);
		inFile.getline(faculty[no_of_student], 99);
		inFile.getline(ic[no_of_student], 99);
		inFile.getline(year_enroll[no_of_student], 99);
		inFile.getline(email[no_of_student], 99);
		inFile.getline(phone_no[no_of_student], 99);
		inFile.getline(whitespace, 99);
		no_of_student++;
	}
	inFile.close();
	while (decision != 7)
	{
		decision = list1.printMenu();
		switch (decision)
		{
			case 1:
			{
				get1.dataAdd(name, id, faculty, ic, year_enroll, email, phone_no, no_of_student);
			}
				break;
			case 2:
			{
			    list1.printList(name, id, faculty, ic, year_enroll, email, phone_no, count, no_of_student, 1);
			    get1.dataUpdate(name, id, faculty, year_enroll, email, phone_no, no_of_student);
			}
				break;
			case 3:
			{
			    list1.printList(name, id, faculty, ic, year_enroll, email, phone_no, count, no_of_student, 1);
			    get1.dataDelete(name, id, faculty, ic, year_enroll, email, phone_no, no_of_student);
			}
				break;
			case 4:
			{
				list1.printList(name, id, faculty, ic, year_enroll, email, phone_no, count, no_of_student, 1);
			}
                break;
			case 5:
			{
			    obj1.searchGender(ic, count, no_of_student);
			    list2.printList(name, id, faculty, ic, year_enroll, email, phone_no, count, no_of_student, 0);
			}
                break;
			case 6:
            {
                obj1.searchKeyword(name, id, faculty, ic, year_enroll, email, phone_no, count, no_of_student);
                list2.printList(name, id, faculty, ic, year_enroll, email, phone_no, count, no_of_student, 0);
            }

		}
		for (int x = 0; x < no_of_student; x++)
			count[x] = 0;
		if (decision != 7)
		{
			cout << " Press enter to go back to menu . . . ";
			cin.ignore(INT_MAX, '\n');
			system("cls");
		}
	}
	ofstream outFile("record.txt", ios::out);
	for (int x = 0; x < no_of_student; x++)
	{
		outFile << name[x] << endl;
		outFile << id[x] << endl;
		outFile << faculty[x] << endl;
		outFile << ic[x] << endl;
		outFile << year_enroll[x] << endl;
		outFile << email[x] << endl;
		outFile << phone_no[x] << endl;
		if (x != no_of_student - 1)
			outFile << endl;
	}
	outFile.close();
	cout << "\n Thank you for using this system! " << endl << endl;
}
int Print::printMenu()
{
	char decision[99];
	int decision_2;
	cout << endl;
	cout << "     ---------------------------------------------------" << endl;
	cout << "     Welcome to the Student Database Management System !" << endl;
	cout << "     ---------------------------------------------------" << endl << endl;
	cout << "   ======================================================" << endl;
	cout << left << setw(27) << "   1 - Add Record" << setw(15) << "  5 - Search Record by Gender"  << endl;
	cout << setw(27) << "   2 - Update Record" << setw(15) << "  6 - Search Record by Keyword"  << endl;
	cout << setw(27) << "   3 - Delete Record" << setw(15) << "  7 - Exit" << endl;
	cout << setw(27) << "   4 - List Record" << endl;
	cout << "   ======================================================" << endl;
	cout << "\n    Please enter your choice: " << right;
	cin >> decision;
	while (strcmp(decision, "1") && strcmp(decision, "2") && strcmp(decision, "3") && strcmp(decision, "4") && strcmp(decision, "5") && strcmp(decision, "6") && strcmp(decision, "7"))
	{
		cout << "\n Please key in correctly! ( 1 - 7 ) >> ";
		cin.getline(decision, 99);
	}
	if(strcmp(decision,"7"))
		system("cls");
	decision_2 = (int)(decision[0] - '0');
	return decision_2;
}

void Print::printList(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int count[], int no_of_student, int special_case)
{
	int total = 0;
	bool proceed = false;
	for (int y = 0; y < no_of_student; y++)
	{
		if (count[y] == 1 || special_case)
		{
			proceed = true;
		}
	}
	if (proceed)
	{
		cout << left << endl;
		cout << " _________________________________________________________________________________________________________________________";
		cout << "______________________\n";
		cout << setw(144) << "|" << "|\n";
		cout << setw(24) << "| Student Name" << setw(19) << "Student ID" << setw(27) << "Faculty" << setw(21) << "IC Number";
		cout << setw(17) << "Year Enrolled" << setw(23) << "Email Address" << "Contact No.  |" << "\n";
		cout << "|_________________________________________________________________________________________________________________________";
		cout << "______________________|\n";
		cout << setw(144) << "|" << "|\n";
		for (int x = 0; x < no_of_student; x++)
		{
			if (count[x] == 1 || special_case)
			{
				cout << "| ";
				cout << setw(22) << name[x] << setw(19) << id[x] << setw(27) << faculty[x] << setw(21) << ic[x];
				cout << setw(17) << year_enroll[x] << setw(23) << email[x] << setw(13) << phone_no[x] << "|\n";
				total++;
			}
		}
		cout << "|_________________________________________________________________________________________________________________________";
		cout << "______________________|\n";
		cout << "\n Total number of records found : " << total << "\n\n";
	}
	else
	{
		cout << "\n No record found!";
	}
}

void Data::dataAdd(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int& no_of_student)
{
	char decision[99];
	cout << "\n Create a new data? ( 1 - Yes | 2 - No ) >> ";
	cin.getline(decision, 99);
	while (strcmp(decision, "1") && strcmp(decision, "2"))
	{
		cout << "\n Please key in correctly! ( 1 / 2 )>> ";
		cin.getline(decision, 99);
	}
	cout << endl;
	if (!strcmp(decision,"1"))
	{
		cout << left;
		cout << setw(17) << " Record no." << ": " << no_of_student + 1 << endl;
		cout << setw(17) << " Name" << ": ";
		cin.getline(name[no_of_student], 99);
		cout << setw(17) << " ID" << ": ";
		cin.getline(id[no_of_student], 99);
		cout << setw(17) << " Faculty" << ": ";
		cin.getline(faculty[no_of_student], 99);
		cout << setw(17) << " IC number" << ": ";
		cin.getline(ic[no_of_student], 99);
		cout << setw(17) << " Year Enrolled" << ": ";
		cin.getline(year_enroll[no_of_student], 99);
		cout << setw(17) << " Email Address" << ": ";
		cin.getline(email[no_of_student], 99);
		cout << setw(17) << " Contact number" << ": ";
		cin.getline(phone_no[no_of_student], 99);
		no_of_student++;
		cout << "\n New record has been created successfully.";
	}
}

void Data::dataUpdate(char name[][99], char id[][99], char faculty[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int no_of_student)
{
	int y = -1;
	char name_2[99], id_2[99];
	char new_faculty[99], new_address[99], new_phone_no[99], new_year_enroll[99];
	cout << "\n Please enter the name of the Student that you wanted to update. >> ";
	cin.getline(name_2,99);
	cout << "\n Please enter the Student ID. >> ";
	cin.getline(id_2, 99);
	for (int x = 0; x < no_of_student; x++)
	{
		if (!_stricmp(name_2, name[x]))
		{
			if (!strcmp(id_2, id[x]))
			{
				y = x;
				x = no_of_student;
			}
		}
	}
	if (y != -1)
	{
		cout << "\n Please key in the new faculty for " << name[y] << ". >> ";
		cin.getline(new_faculty, 99);
		cout << "\n Please key in the new email address. >> ";
		cin.getline(new_address, 99);
		cout << "\n Please key in the new contact number. >> ";
		cin.getline(new_phone_no, 99);
		cout << "\n Please key in the new enrollment year. >> ";
		cin.getline(new_year_enroll, 99);
		strcpy(faculty[y], new_faculty);
		strcpy(email[y], new_address);
		strcpy(phone_no[y], new_phone_no);
		strcpy(year_enroll[y], new_year_enroll);
		cout << "\n Updated successfully.";
	}
	else
		cout << "\n No record found!";
}

void Data::dataDelete(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int& no_of_student)
{
	char name_2[99], id_2[99];
	int y = -1;
	char decision[99];
	cout << "\n Please enter the name of the student of the record that you wanted to delete. >> ";
	cin.getline(name_2, 99);
	cout << "\n Please enter the student ID. >> ";
	cin.getline(id_2,99);
	for (int x = 0; x < no_of_student; x++)
	{
		if (!_stricmp(name_2, name[x]))
		{
			if (!strcmp(id_2, id[x]))
			{
				y = x;
				x = no_of_student;
			}
		}
	}
	if (y != -1)
	{
		cout << "\n Are you sure you want to delete this record? ( 1 - Yes | 2 - No ) >> ";
		cin.getline(decision,99);
		while (strcmp(decision, "1") && strcmp(decision, "2"))
		{
			cout << "\n Please key in correctly! ( 1 / 2 ) >> ";
			cin.getline(decision, 99);
		}
		cout << endl;
		if (!strcmp(decision,"1"))
		{
			for (int z = y + 1; z < no_of_student; z++)
			{
				strcpy(name[z - 1], name[z]);
				strcpy(id[z - 1], id[z]);
				strcpy(faculty[z - 1], faculty[z]);
				strcpy(ic[z - 1], ic[z]);
				strcpy(year_enroll[z - 1], year_enroll[z]);
				strcpy(email[z - 1], email[z]);
				strcpy(phone_no[z - 1], phone_no[z]);
			}
			no_of_student--;
			cout << " The record has been successfully deleted.";
		}
	}
	else
		cout << "\n No record found!";
}

void Search::searchGender(char ic[][99], int count[], int no_of_student)
{
	char decision[99];
	int gender;
	char gender_ic;
	cout << "\n Please choose the gender ( 1 - Male | 2 - Female ) >> ";
	cin.getline(decision, 99);
	while (strcmp(decision, "1") && strcmp(decision, "2"))
	{
		cout << "\n Please key in correctly! ( 1 / 2 ) >> ";
		cin.getline(decision, 99);
	}
	gender = (int)(decision[0] - '0');
	for (int x = 0; x < no_of_student; x++)
	{
		if (gender % 2 == ((int)(ic[x][11])) % 2)
			count[x] = 1;
	}
}

void Search::searchKeyword(char name[][99], char id[][99], char faculty[][99], char ic[][99], char year_enroll[][99], char email[][99], char phone_no[][99], int count[], int no_of_student)
{
	int space = 0;
	char temp_name[99][99], temp_position[99][99], temp_address[99][99];
	char keyword[99];
	cout << "\n Please enter a keyword. >> ";
	cin.getline(keyword, 99);
	for (int a = 0; a < strlen(keyword); a++)
	{
		if (keyword[a] == ' ')
			space++;
	}
	while (strlen(keyword) < 2 + space)
	{
		space = 0;
		cout << "\n The keyword must contain at least 2 alphabets or digits. \n\n Please enter a keyword. >> ";
		cin.getline(keyword, 99);
		for (int a = 0; a < strlen(keyword); a++)
		{
			if (keyword[a] == ' ')
				space++;
		}
	}
	for (int z = 0; z < strlen(keyword); z++)
		keyword[z] = toupper(keyword[z]);
	for (int x = 0; x < no_of_student; x++)
	{
		for (int y = 0; y < strlen(name[x]); y++)
		{
			temp_name[x][y] = toupper(name[x][y]);
			temp_name[x][strlen(name[x])] = '\0';

		}
		for (int y = 0; y < strlen(faculty[x]); y++)
		{
			temp_position[x][y] = toupper(faculty[x][y]);
			temp_position[x][strlen(faculty[x])] = '\0';

		}
		for (int y = 0; y < strlen(email[x]); y++)
		{
			temp_address[x][y] = toupper(email[x][y]);
			temp_address[x][strlen(email[x])] = '\0';

		}
		if (strstr(temp_name[x], keyword))
			count[x] = 1;
		if (strstr(temp_position[x], keyword))
			count[x] = 1;
		if (strstr(temp_address[x], keyword))
			count[x] = 1;
		if (strstr(ic[x], keyword))
			count[x] = 1;
		if (strstr(phone_no[x], keyword))
			count[x] = 1;
		if (strstr(year_enroll[x], keyword))
			count[x] = 1;
		if (strstr(id[x], keyword))
			count[x] = 1;
	}
}
